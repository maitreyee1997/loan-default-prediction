from flask import Flask, request, render_template, jsonify
import joblib
import numpy as np

app = Flask(__name__)

model = joblib.load("models/xgb_model.pkl")
scaler = joblib.load("models/scaler.pkl")

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    data = request.json
    features = np.array(data["features"]).reshape(1, -1)
    scaled = scaler.transform(features)
    pred = model.predict(scaled)
    return jsonify({"loan_default_prediction": int(pred[0])})

if __name__ == "__main__":
    app.run()


